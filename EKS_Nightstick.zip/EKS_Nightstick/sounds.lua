function playBatonSound(type)
    if type == "out" then
        SendNUIMessage({ type = "playSound", sound = "html/batonout.ogg" })
    elseif type == "in" then
        SendNUIMessage({ type = "playSound", sound = "html/batonin.ogg" })
    end
end
