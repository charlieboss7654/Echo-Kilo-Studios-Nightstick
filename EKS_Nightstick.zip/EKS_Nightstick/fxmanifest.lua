fx_version 'cerulean'
game 'gta5'

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/batonout.ogg',
    'html/batonin.ogg',
    'stream/w_me_nightstick.ydr',
    'stream/w_me_nightstick.ytd',
}

client_scripts {
    'client.lua'      
}

data_file 'DLC_ITYP_REQUEST' 'stream/w_me_nightstick.ydr'
