local active = {}

RegisterNetEvent("eks_nightstick:smashWindow", function(vehicleNetId, windowIndex)
    vehicleNetId = tonumber(vehicleNetId)
    windowIndex = tonumber(windowIndex)
    if not vehicleNetId or vehicleNetId == 0 then return end
    if windowIndex == nil then return end

    TriggerClientEvent("eks_nightstick:syncSmashWindow", -1, vehicleNetId, windowIndex)
end)

RegisterNetEvent("eks_nightstick:requestEject", function(targetServerId, vehicleNetId, seat)
    local src = source

    targetServerId = tonumber(targetServerId)
    vehicleNetId = tonumber(vehicleNetId)
    seat = tonumber(seat)

    if not targetServerId or not seat then return end
    if active[targetServerId] then return end

    active[targetServerId] = true

    TriggerClientEvent("eks_nightstick:startEjectMinigame", targetServerId, src, vehicleNetId or 0, seat)

    SetTimeout(6000, function()
        active[targetServerId] = nil
    end)
end)

RegisterNetEvent("eks_nightstick:ejectResult", function(attackerServerId, success)
    local src = source
    attackerServerId = tonumber(attackerServerId)
    active[src] = nil
end)

AddEventHandler("playerDropped", function()
    local src = source
    active[src] = nil
end)
