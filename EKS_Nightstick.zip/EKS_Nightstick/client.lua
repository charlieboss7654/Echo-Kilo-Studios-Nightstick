local seatBones = {
    [-1] = "window_lf",
    [0] = "window_rf",
    [1] = "window_lr",
    [2] = "window_rr",
}

local seatToWindowIndex = {
    [-1] = 0,
    [0] = 1,
    [1] = 2,
    [2] = 3
}

local promptDistance = 2.0
local lastWeapon = nil

-- Main loop
Citizen.CreateThread(function()
    while true do
        Wait(0)
        local player = PlayerPedId()
        local weapon = GetSelectedPedWeapon(player)

        if weapon == GetHashKey("WEAPON_NIGHTSTICK") then
            local vehicle = getVehicleInFront(player)

            if vehicle and IsEntityAVehicle(vehicle) then
                local seat, hitPos = getClosestWindowSeat(vehicle)

                if seat and hitPos then
                    local windowIndex = seatToWindowIndex[seat] or 0
                    local seatOccupied = not IsVehicleSeatFree(vehicle, seat)
                    local target = GetPedInVehicleSeat(vehicle, seat)

                    if IsVehicleWindowIntact(vehicle, windowIndex) then
                        DrawText3D(hitPos, "[E] Smash Window")
                        if IsControlJustReleased(0, 38) then -- E
                            SmashVehicleWindow(vehicle, windowIndex)
                            PlaySoundFromCoord(-1, "Break_Window", hitPos, "DLC_HEIST_BIOLAB_PREP_HACKING_SOUNDS", 0, 0, 0)
                        end
                    elseif seatOccupied and target ~= 0 and DoesEntityExist(target) then
                        DrawText3D(hitPos, "[G] Eject Occupant")
                        if IsControlJustReleased(0, 47) then -- G
                            ClearPedTasksImmediately(target)
                            TaskLeaveVehicle(target, vehicle, 16)
                        end
                    end
                end
            end
        end
    end
end)

-- Baton sound playback using NUI
Citizen.CreateThread(function()
    while true do
        Wait(100)
        local player = PlayerPedId()
        local currentWeapon = GetSelectedPedWeapon(player)

        if currentWeapon ~= lastWeapon then
            if currentWeapon == GetHashKey("WEAPON_NIGHTSTICK") then
                SendNUIMessage({ type = "playSound", sound = "batonout.ogg" })
            elseif lastWeapon == GetHashKey("WEAPON_NIGHTSTICK") then
                SendNUIMessage({ type = "playSound", sound = "batonin.ogg" })
            end
            lastWeapon = currentWeapon
        end
    end
end)

-- Vehicle detection
function getVehicleInFront(player)
    local coords = GetEntityCoords(player)
    local forward = GetOffsetFromEntityInWorldCoords(player, 0.0, 2.0, 0.0)
    local ray = StartShapeTestRay(coords.x, coords.y, coords.z, forward.x, forward.y, forward.z, 10, player, 0)
    local _, _, _, _, entity = GetShapeTestResult(ray)
    if entity and IsEntityAVehicle(entity) then
        return entity
    end
    return nil
end

-- Seat & position detection
function getClosestWindowSeat(vehicle)
    local playerCoords = GetEntityCoords(PlayerPedId())
    local minDist = promptDistance
    local closestSeat = nil
    local closestPos = nil

    for seat, boneName in pairs(seatBones) do
        local boneIndex = GetEntityBoneIndexByName(vehicle, boneName)
        local pos

        if boneIndex ~= -1 then
            pos = GetWorldPositionOfEntityBone(vehicle, boneIndex)
        elseif seat == -1 then
            pos = GetOffsetFromEntityInWorldCoords(vehicle, -0.6, 0.3, 0.6)
        elseif seat == 0 then
            pos = GetOffsetFromEntityInWorldCoords(vehicle, 0.6, 0.3, 0.6)
        elseif seat == 1 then
            pos = GetOffsetFromEntityInWorldCoords(vehicle, -0.6, -1.0, 0.6)
        elseif seat == 2 then
            pos = GetOffsetFromEntityInWorldCoords(vehicle, 0.6, -1.0, 0.6)
        end

        if pos then
            local dist = #(playerCoords - pos)
            if dist < minDist then
                minDist = dist
                closestSeat = seat
                closestPos = pos
            end
        end
    end

    return closestSeat, closestPos
end

-- 3D text display
function DrawText3D(coords, text)
    local x, y, z = table.unpack(coords)
    local onScreen, sx, sy = World3dToScreen2d(x, y, z + 0.2)
    if onScreen then
        SetTextScale(0.4, 0.4)
        SetTextFont(4)
        SetTextProportional(1)
        SetTextOutline()
        SetTextEntry("STRING")
        AddTextComponentString(text)
        DrawText(sx, sy)
    end
end
