local seatBones = {
    [-1] = "window_lf",
    [0]  = "window_rf",
    [1]  = "window_lr",
    [2]  = "window_rr",
}

local seatToWindowIndex = {
    [-1] = 0,
    [0]  = 1,
    [1]  = 2,
    [2]  = 3
}

local promptDistance = 2.0
local lastWeapon = nil

local smashedWindows = {} -- [vehNetId] = { [windowIndex] = true }

local ejectBusy = false
local ejectCtx = nil

local function markWindowSmashed(vehNetId, windowIndex)
    if not vehNetId or vehNetId == 0 then return end
    smashedWindows[vehNetId] = smashedWindows[vehNetId] or {}
    smashedWindows[vehNetId][windowIndex] = true
end

local function isWindowSmashed(vehicle, windowIndex)
    if not DoesEntityExist(vehicle) then return false end
    local netId = VehToNet(vehicle)
    if netId and netId ~= 0 and smashedWindows[netId] and smashedWindows[netId][windowIndex] then
        return true
    end
    return not IsVehicleWindowIntact(vehicle, windowIndex)
end

local function ensureControl(entity, timeoutMs)
    if not DoesEntityExist(entity) then return false end
    timeoutMs = timeoutMs or 750
    if NetworkHasControlOfEntity(entity) then return true end
    NetworkRequestControlOfEntity(entity)
    local start = GetGameTimer()
    while not NetworkHasControlOfEntity(entity) and (GetGameTimer() - start) < timeoutMs do
        Wait(0)
        NetworkRequestControlOfEntity(entity)
    end
    return NetworkHasControlOfEntity(entity)
end

local function applySmash(vehicle, windowIndex)
    if not DoesEntityExist(vehicle) then return end
    ensureControl(vehicle, 800)

    if IsVehicleWindowIntact(vehicle, windowIndex) then
        SmashVehicleWindow(vehicle, windowIndex)
        -- Some vehicles need this too for consistent visuals:
        if SetVehicleWindowBroken then
            pcall(function()
                SetVehicleWindowBroken(vehicle, windowIndex, true)
            end)
        end
    end

    local netId = VehToNet(vehicle)
    markWindowSmashed(netId, windowIndex)
end

-- MAIN LOOP (smash + eject prompt)
Citizen.CreateThread(function()
    while true do
        Wait(0)

        local player = PlayerPedId()
        local weapon = GetSelectedPedWeapon(player)

        if weapon == GetHashKey("WEAPON_NIGHTSTICK") then
            local vehicle = getVehicleInFront(player)

            if vehicle and IsEntityAVehicle(vehicle) then
                local seat, hitPos = getClosestWindowSeat(vehicle)

                if seat and hitPos then
                    local windowIndex = seatToWindowIndex[seat] or 0
                    local seatOccupied = not IsVehicleSeatFree(vehicle, seat)
                    local target = GetPedInVehicleSeat(vehicle, seat)

                    if not isWindowSmashed(vehicle, windowIndex) then
                        DrawText3D(hitPos, "[E] Smash Window")
                        if IsControlJustReleased(0, 38) then -- E
                            applySmash(vehicle, windowIndex)
                            TriggerServerEvent("eks_nightstick:smashWindow", VehToNet(vehicle), windowIndex)
                            PlaySoundFromCoord(-1, "Break_Window", hitPos, "DLC_HEIST_BIOLAB_PREP_HACKING_SOUNDS", 0, 0, 0)
                        end
                    else
                        if seatOccupied and target ~= 0 and DoesEntityExist(target) then
                            DrawText3D(hitPos, "[G] Eject Occupant")
                            if IsControlJustReleased(0, 47) then -- G
                                if IsPedAPlayer(target) then
                                    local targetPlayer = NetworkGetPlayerIndexFromPed(target)
                                    if targetPlayer and targetPlayer ~= -1 then
                                        local targetServerId = GetPlayerServerId(targetPlayer)
                                        TriggerServerEvent("eks_nightstick:requestEject", targetServerId, VehToNet(vehicle), seat)
                                    end
                                else
                                    ClearPedTasksImmediately(target)
                                    TaskLeaveVehicle(target, vehicle, 16)
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end)

-- Baton sound playback using NUI
Citizen.CreateThread(function()
    while true do
        Wait(100)
        local player = PlayerPedId()
        local currentWeapon = GetSelectedPedWeapon(player)

        if currentWeapon ~= lastWeapon then
            if currentWeapon == GetHashKey("WEAPON_NIGHTSTICK") then
                SendNUIMessage({ type = "playSound", sound = "batonout.ogg" })
            elseif lastWeapon == GetHashKey("WEAPON_NIGHTSTICK") then
                SendNUIMessage({ type = "playSound", sound = "batonin.ogg" })
            end
            lastWeapon = currentWeapon
        end
    end
end)

-- Sync window smash to everyone
RegisterNetEvent("eks_nightstick:syncSmashWindow", function(vehicleNetId, windowIndex)
    vehicleNetId = tonumber(vehicleNetId)
    windowIndex = tonumber(windowIndex)

    if not vehicleNetId or vehicleNetId == 0 then return end
    if windowIndex == nil then return end

    local veh = NetToVeh(vehicleNetId)
    if DoesEntityExist(veh) then
        applySmash(veh, windowIndex)
    else
        -- Still store state so prompts behave even if entity streams in later
        markWindowSmashed(vehicleNetId, windowIndex)
    end
end)

-- Start eject resist minigame on the OCCUPANT
RegisterNetEvent("eks_nightstick:startEjectMinigame", function(attackerServerId, vehicleNetId, seat)
    if ejectBusy then return end

    attackerServerId = tonumber(attackerServerId)
    seat = tonumber(seat)

    local ped = PlayerPedId()
    local veh = GetVehiclePedIsIn(ped, false)
    if veh == 0 then return end

    -- We deliberately DON'T rely on NetToVeh(vehicleNetId) here; using current vehicle is more reliable.
    if GetPedInVehicleSeat(veh, seat) ~= ped then return end

    ejectBusy = true
    ejectCtx = { attacker = attackerServerId, seat = seat }

    local zoneStart = math.random()
    local zoneSize = 0.14 + (math.random() * 0.08)
    local speed = 1.25 + (math.random() * 0.75)
    local duration = 3200

    SendNUIMessage({
        type = "startEject",
        zoneStart = zoneStart,
        zoneSize = zoneSize,
        speed = speed,
        duration = duration
    })

    SetNuiFocus(true, false)
end)

RegisterNUICallback("ejectResult", function(data, cb)
    local success = (data and data.success) == true

    if ejectCtx and ejectCtx.attacker then
        TriggerServerEvent("eks_nightstick:ejectResult", ejectCtx.attacker, success)
    end

    SetNuiFocus(false, false)

    if not success then
        local ped = PlayerPedId()
        local veh = GetVehiclePedIsIn(ped, false)
        if veh ~= 0 and GetPedInVehicleSeat(veh, ejectCtx.seat) == ped then
            ClearPedTasksImmediately(ped)
            TaskLeaveVehicle(ped, veh, 16)
        end
    end

    ejectBusy = false
    ejectCtx = nil

    if cb then cb("ok") end
end)

-- Vehicle detection
function getVehicleInFront(player)
    local coords = GetEntityCoords(player)
    local forward = GetOffsetFromEntityInWorldCoords(player, 0.0, 2.0, 0.0)
    local ray = StartShapeTestRay(coords.x, coords.y, coords.z, forward.x, forward.y, forward.z, 10, player, 0)
    local _, _, _, _, entity = GetShapeTestResult(ray)
    if entity and IsEntityAVehicle(entity) then
        return entity
    end
    return nil
end

-- Seat & position detection
function getClosestWindowSeat(vehicle)
    local playerCoords = GetEntityCoords(PlayerPedId())
    local minDist = promptDistance
    local closestSeat = nil
    local closestPos = nil

    for seat, boneName in pairs(seatBones) do
        local boneIndex = GetEntityBoneIndexByName(vehicle, boneName)
        local pos

        if boneIndex ~= -1 then
            pos = GetWorldPositionOfEntityBone(vehicle, boneIndex)
        elseif seat == -1 then
            pos = GetOffsetFromEntityInWorldCoords(vehicle, -0.6, 0.3, 0.6)
        elseif seat == 0 then
            pos = GetOffsetFromEntityInWorldCoords(vehicle, 0.6, 0.3, 0.6)
        elseif seat == 1 then
            pos = GetOffsetFromEntityInWorldCoords(vehicle, -0.6, -1.0, 0.6)
        elseif seat == 2 then
            pos = GetOffsetFromEntityInWorldCoords(vehicle, 0.6, -1.0, 0.6)
        end

        if pos then
            local dist = #(playerCoords - pos)
            if dist < minDist then
                minDist = dist
                closestSeat = seat
                closestPos = pos
            end
        end
    end

    return closestSeat, closestPos
end

-- 3D text helper
function DrawText3D(coords, text)
    local x, y, z = coords.x, coords.y, coords.z
    local onScreen, sx, sy = World3dToScreen2d(x, y, z + 0.2)
    if onScreen then
        SetTextScale(0.4, 0.4)
        SetTextFont(4)
        SetTextProportional(1)
        SetTextOutline()
        SetTextEntry("STRING")
        AddTextComponentString(text)
        DrawText(sx, sy)
    end
end
